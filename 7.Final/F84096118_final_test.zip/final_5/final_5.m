T=0:0.01:100;
Y1=[0 3 20];
Y2=[0.01 3 20];
[t1,y1] = ode45(@func,T,Y1);
[t2,y2] = ode45(@func,T,Y2);
figure(1),plot3(y1(:,1),y1(:,2),y1(:,3),'-b');
hold on
figure(1),plot3(y2(:,1),y2(:,2),y1(:,3),'--.r');
figure.axis=[-15 15 -15 15]'
plot3(Y1(1),Y1(2),Y1(3),'o','MarkerFaceColor','k')
plot3(Y2(1),Y2(2),Y2(3),'o','MarkerFaceColor','k')
xlabel('X');
ylabel('Y');
zlabel('Z');
legend({'x init 0','x init 0.01'})
hold off