function f = func(t,x)%x(1)->x; x(2)->y; x(3)->z
    a = 0.2;b = 0.2;c = 5.7;
    f(1) = -x(2)-x(3);
    f(2) = x(1)+a*x(2);
    f(3) = b+x(3)*(x(1)-c);
    f = f(:);
end