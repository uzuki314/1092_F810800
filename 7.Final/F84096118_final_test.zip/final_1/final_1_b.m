for ii = 1:30
    [t1 t2 t3 t4]= textread(strcat('id_',num2str(109300+ii),'.dat'),'%n%n%n%n');
    data(1,ii) = mean(t1');
    data(2,ii) = mean(t2');
    data(3,ii) = mean(t3');
    data(4,ii) = mean(t4');
end
T = char('Chinese','English','Math','Science');
for index = 1:4
    subplot(4, 1, index);
    histogram(data(index,:),10);
    title(T(index,:));
end