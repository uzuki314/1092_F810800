rng(84096118);
ch_avg_std = [70,25 ; 64,30 ; 78,20];
en_avg_std = [75,15 ; 71,22 ; 68,30];
mt_avg_std = [66,32 ; 60,34 ; 63,31];
sc_avg_std = [78,17 ; 74,20 ; 69,24];
for index = 1:3
    ch(:,index) = floor(ch_avg_std(index,1)+ch_avg_std(index,2)*randn(1,30));
    ch(:,index) = ch(:,index).*not(ch(:,index)>=100)+(ch(:,index)>=100)*100;
    ch(:,index) = ch(:,index).*not(ch(:,index)<=10 )+(ch(:,index)<=10 )*10 ;
    en(:,index) = floor(en_avg_std(index,1)+en_avg_std(index,2)*randn(1,30));
    en(:,index) = en(:,index).*not(en(:,index)>=100)+(en(:,index)>=100)*100;
    en(:,index) = en(:,index).*not(en(:,index)<=10 )+(en(:,index)<=10 )*10 ;
    mt(:,index) = floor(mt_avg_std(index,1)+mt_avg_std(index,2)*randn(1,30));
    mt(:,index) = mt(:,index).*not(mt(:,index)>=100)+(mt(:,index)>=100)*100;
    mt(:,index) = mt(:,index).*not(mt(:,index)<=10 )+(mt(:,index)<=10 )*10 ;
    sc(:,index) = floor(sc_avg_std(index,1)+sc_avg_std(index,2)*randn(1,30));
    sc(:,index) = sc(:,index).*not(sc(:,index)>=100)+(sc(:,index)>=100)*100;
    sc(:,index) = sc(:,index).*not(sc(:,index)<=10 )+(sc(:,index)<=10 )*10 ;
end
for ii = 1:30
    fid = fopen(strcat('id_',num2str(109300+ii),'.dat'),'w+');
    for jj = 1:3
        fprintf(fid,'%g ', ch(ii,jj));
        fprintf(fid,'%g ', en(ii,jj));
        fprintf(fid,'%g ', mt(ii,jj));
        fprintf(fid,'%g ', sc(ii,jj));
        fprintf(fid,'\n');
    end
    fclose(fid);
end