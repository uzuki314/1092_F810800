[x,rect1,rect2]=textread('./x_rect.dat',"%f %f %f");
X= x./2;
subplot(2,1,1);
hold on
plot(x,rect1);
plot(x,rect2);
xlabel('x');
ylabel('Amplitude');
legend({'a=0.2','a=1'})
set(gca,'FontWeight','bold','fontsize',14);
hold off
subplot(2,1,2);
hold on
plot(X,fftshift(abs(fft(rect1))));
plot(X,fftshift(abs(fft(rect2))));
xlabel('1/x');
ylabel('Magnitude');
legend({'a=0.2','a=1'})
set(gca,'FontWeight','bold','fontsize',14);
hold off