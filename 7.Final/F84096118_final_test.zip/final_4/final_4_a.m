x = [-10:0.01:10];
rect1 = @(x)(x>-0.19999)*(x<0.19999);
rect2 = @(x)(x>-1)*(x<1);
fid = fopen('./x_rect.dat','w+');
for ii = 1:length(x)
    fprintf(fid,"%f %f %f\n",x(ii),rect1(x(ii)),rect2(x(ii)));
end
fclose(fid);