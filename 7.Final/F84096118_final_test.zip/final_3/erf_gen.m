function result = erf_gen(x,s)
    tmp = size(x);
    if nargin < 1
        error(message('stats:erf_gen:TooFewInputs'));
    elseif nargin == 1
        result = erf(x);
    elseif nargin ==2
        if s=='exact'
            for index = 1:1:tmp(2)
                result(index) = 1/sqrt(pi)*integral(@(t)exp(-t.^2), -x(index), x(index));
            end
        elseif s=='appro'
            p = 0.47047;
            a1 = 0.3480242;
            a2 = -0.0958798;
            a3 = 0.7478556;
            t = @(x)1./(1+p*x);
            for index = 1:1:tmp(2)
                if x(index)<0
                    x(index) = x(index)*-1;
                    result(index) = -1*(1-(a1*t(x(index)) + a2*t(x(index))^2 + a3*t(x(index))^3)*exp(-x(index)^2));
                else
                    result(index) = 1-(a1*t(x(index)) + a2*t(x(index))^2 + a3*t(x(index))^3)*exp(-x(index)^2);    
                end
            end
            
        else 
            error(message('stats:erf_gen:Illegalparameter'));
        end
    elseif nargin > 2
        error(message('stats:erf_gen:TooMuchInputs'));
    end
end