x = -5:0.05:5;
subplot(2,1,1);
hold on
plot(x,erf_gen(x,'appro'),'--b');
plot(x,erf_gen(x,'exact'),':r');
xlabel('X');
ylabel('erf(x)')
legend({'erf\_gen(x,''appro'') vs. x','erf\_gen(x,''exact'') vs. x'},'Location','southeast')
hold off
subplot(2,1,2)
hold on
plot(x,3*erf_gen(0.5*x,'appro'),'--r');
plot(x,-erf_gen(x),':g');
plot(x,3*erf_gen(0.5*x,'appro')-erf_gen(x),'-.b');
xlabel('X');
ylabel('erf\_gen(x)')
legend({'3*erf\_gen(0.5*x,''appro'') vs. x','-erf\_gen(x,''exact'') vs. x','3*erf\_gen(0.5*x,''appro'')-erf\_gen(x) vs. x'},'Location','southeast')
hold off
erf_gen(2.0,'other')