e = @(x) 5*cosh(x);
f = @(x) 2*tanh(x);
g = @(x) 3*sinh(x);
h = @(a,b,c) sqrt(a.^2+b.^2+c.^2);
x = [-5*pi:0.1*pi:5*pi];
semilogy(x,h(e(x),f(x),g(x)))
xlabel('X')
ylabel('h(e(x),f(x),g(x))')