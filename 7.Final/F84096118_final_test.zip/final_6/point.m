classdef point
    properties
        x
        y
        name
    end
    methods
        function p = point(vec)
            persistent ss;
            if isempty(ss) ss = 1;                
            else ss = ss+1;
            end
            if isa(vec, 'point')
                p = vec(:);
            else
                p.x = vec(1);
                p.y = vec(2);
            end
            p.name = ['p', num2str(ss)];
            s = [p.name, ' is a point with x = ', num2str(p.x), ' and y = ', num2str(p.y)];
            disp(s);
        end
        function d = dist1(p)
            d = sqrt((p.x)^2 + (p.y)^2);
            s = ['The d between ', p.name, ' and O is ', num2str(d)];
            disp(s);
        end
        function d = dist2(p1, p2)
            d = sqrt((p1.x - p2.x)^2 + (p1.y - p2.y)^2);
            s = ['The d between ', p1.name, ' and ', p2.name, ' is ', num2str(d)];
            disp(s);
        end
    end
end