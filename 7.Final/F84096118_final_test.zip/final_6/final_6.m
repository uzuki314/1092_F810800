p1 = point([1.0 2.0]);
p2 = point([2.0 4.0]);
p3 = point(p1);
d1 = dist1(p1);
d2 = dist1(p2);
d32 = dist2(p3, p2);